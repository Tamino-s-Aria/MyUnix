#ifndef _FSCACHE_H
#define _FSCACHE_H

#include <zjunix/fs/fscache.h>

#endif  // _FSCACHE_H