#ifndef _VGA_H
#define _VGA_H

#include <driver/vga.h>

#endif
