#ifndef _LOCK_H
#define _LOCK_H

#include <zjunix/lock.h>

#endif
