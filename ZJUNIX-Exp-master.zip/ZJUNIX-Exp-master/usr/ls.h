
#ifndef _LS_H
#define _LS_H

int ls(char *para);

#endif
