#ifndef _PC_H
#define _PC_H

#include <zjunix/pc.h>

#endif
