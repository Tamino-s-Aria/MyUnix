#ifndef _PS_H
#define _PS_H
void ps();
void parse_cmd();
#endif
